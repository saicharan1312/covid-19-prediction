"""internship URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from pages import views
from django.conf.urls import *
from django.conf import settings
from django.conf.urls.static import static




urlpatterns = [
    url(r'^admin/', admin.site.urls),
	path('',views.home,name='home'),
    path('login/',views.login,name='login'),
    path('login/register/',views.register,name='register'),
    path('register/register',views.register,name='register'),
    path('register/',views.register,name='register'),
    path('register/logout',views.logout,name='logout'),
    path('register/confirmedcases',views.confirmedcases,name='confirmedcases'),
    path('register/confirmeddeaths',views.confirmeddeaths,name='confirmeddeaths'),
    path('register/dataenter',views.dataenter,name='dataenter'),
    path('register/dataenterdeaths',views.dataenterdeaths,name='dataenterdeaths'),
    path('register/predictions',views.register,name='register'),
    path('login/register/predictions',views.register,name='predictions'),
    path('login/predictions',views.predict,name='predictions'),
    path('login/details/',views.details,name='details'),
    path('contact/',views.contact,name='contact'),
    path('details/',views.details,name='details'),
    path('about/',views.about,name='about'),
    path('login/dataenterdeaths/',views.confirmeddeaths,name='dataenterdeaths'),
    path('login/dataenter/',views.confirmedcases,name='dataenter'),
    path('login/dataenter/logout/',views.logout,name='logout'),
    path('login/dataenter/confirmedcases',views.confirmedcases,name='confirmedcases'),
    path('login/dataenter/confirmeddeaths',views.confirmeddeaths,name='confirmeddeaths'),]

urlpatterns=urlpatterns + static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
