from django.db import models
class destination(models.Model):
    username = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    password = models.CharField(max_length=100)

class prediction(models.Model):
   d= models.IntegerField()
   #dc = models.IntegerField()
   dr= models.IntegerField()
   tr= models.IntegerField()
   dd = models.IntegerField()
   #td= models.IntegerField()
   predicted=models.IntegerField()
