from django.http import HttpResponse
from django.shortcuts import render,redirect
from pages.models import destination,prediction
from django.contrib import messages

# Create your views here.
def home(request):
	return render(request,"home.html",{})


def register(request):
    if request.method =="POST":
        username=request.POST['username']
        #first_name=request.POST['first name']
        #last_name=request.POST['last name']
        email=request.POST['email']
        password1=request.POST['password1']
        password2=request.POST['password2']

        if password1==password2:
            if destination.objects.filter(username=username).exists():
                messages.info(request,'Username exists,try other')
                return redirect("register")
            elif destination.objects.filter(email=email).exists():
                messages.info(request,'Email already registered')
                return redirect('register')
            else:
                user = destination(username=username,password=password1,email=email)
                user.save();
                print("User created")
                return render(request,"predictions.html")
        else:
            messages.info(request,"password mismatch")
            return redirect('register')
    else :        

        return render(request,"register.html")    


def contact(request):
	return render(request,"contact.html",{})

def login(request):
    if request.method=="POST":
       username=request.POST['username'] 
       password=request.POST['password']
       user=destination(username=username,password=password)
       if user is not None:
           destination(request, user) 
           return redirect("predictions") 
       else:
            messages.info(request,"invalid credentials")
            return redirect("login")

    else:   
        return render(request,"login.html")


def about(request):
	return render(request,"about.html",{})

#def index(request):
	#dests=destination.objects.all()
	#return render(request,"index.html")

def details(request):
    return render(request,"details.html")


def predict(request):
   return render(request,"predictions.html") 


def logout(request):
   return render(request,"logout.html") 

def confirmedcases(request):
    if(request.method == 'POST'):
        d = int(request.POST['Date'])
        #dc = int(request.POST['Daily_Confirmed'])
        dr = int(request.POST['Daily_Recovered'])
        tr= int(request.POST['Total_Recovered'])
        dd = int(request.POST['Daily_Deceased'])
        #td = int(request.POST['Total_Deceased'])
        

        import pandas as pd
        import numpy as np 
        covid=pd.read_csv(r"static/datasets/covid.csv")
        x = covid[['Date','Daily Recovered','Total Recovered','Daily Deceased']]
        y = covid['Total Confirmed']
        from sklearn.model_selection import train_test_split
        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.20, random_state = 0)    
        from sklearn.linear_model import LinearRegression
        mr=LinearRegression()
        mr.fit(x_train,y_train)
        y_pred=mr.predict(x_test)
        predicted=mr.predict([[d,dr,tr,dd]])
        hp = prediction(d=d,dr=dr,tr=tr,dd=dd,predicted=predicted)
        hp.save()
        v=prediction.objects.all()
        for i in v:
            return render(request,"confirmedcases.html",{'predicted':predicted,'d':d,'dr':dr,'tr':tr,'dd':dd})
        

    else:
        return render(request,'dataenter.html')  
   
def dataenter(request):
   return render(request,"dataenter.html")

def dataenterdeaths(request):
   return render(request,"dataenterdeaths.html")

def confirmeddeaths(request):
    if(request.method == 'POST'):
        d = int(request.POST['Date'])
        #dc = int(request.POST['Daily_Confirmed'])
        dr = int(request.POST['Daily_Recovered'])
        tr= int(request.POST['Total_Recovered'])
        dd = int(request.POST['Daily_Deceased'])
        #td = int(request.POST['Total_Deceased'])
        hp = prediction(d=d,dr=dr,tr=tr,dd=dd)
        hp.save()

        import pandas as pd
        import numpy as np 
        covid=pd.read_csv(r"static/datasets/covid.csv")
        x = covid[['Date','Daily Recovered','Total Recovered','Daily Deceased']]
        y = covid['Total Deaths']
        from sklearn.model_selection import train_test_split
        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.20, random_state = 0)    
        from sklearn.linear_model import LinearRegression
        mr=LinearRegression()
        mr.fit(x_train,y_train)
        y_pred=mr.predict(x_test)
        predicted=mr.predict([[d,dr,tr,dd]])
        #predicted=int(request.POST('predicted'))
        hp = prediction(d=d,dr=dr,tr=tr,dd=dd,predicted=predicted)
        hp.save()
        r=predicted[0]
        v=prediction.objects.all()
        for i in v:
            return render(request,"confirmeddeaths.html",{'predicted':r,'d':d,'dr':dr,'tr':tr,'dd':dd})

    else:
        return render(request,'dataenter.html') 

